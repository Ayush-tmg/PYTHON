######## EXERCISE 2 ########

